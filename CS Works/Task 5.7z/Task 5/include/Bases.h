#pragma once

#include <vector>

void basesSort(std::vector<int>& array);
