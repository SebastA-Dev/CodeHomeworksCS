#pragma once

#include <vector>

void radixSort(std::vector<int>& array);
