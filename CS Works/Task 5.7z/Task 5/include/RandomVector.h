#pragma once

#include <vector>
#include <cstddef>

std::vector<int> make_random_vector(std::size_t n);
std::vector<int> make_random_vector_big_numbers(std::size_t n);
