#ifndef ESTRUCTURA1_H     
#define ESTRUCTURA1_H 

struct nodo {
    char dato;
    nodo *sig;
};

template <typename T>
struct nodoT{
    T dato;
    nodoT<T>* sig;
};
#endif
